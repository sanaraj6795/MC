﻿using AutoMapper;
using CustomerApplication.Models;
using CustomerApplication.UserModel;
using System.Collections.Generic;

namespace CustomerApplication.Mapper
{
    public class CustomerMapper : Profile
    {
        public CustomerMapper()
        {
            CreateMap<CustomerModel, Customer>().ReverseMap();
            CreateMap<AddressModel, Address>().ReverseMap();
            CreateMap<Customer, List<CustomerModel>>().ReverseMap();
        }
    }  
    
}

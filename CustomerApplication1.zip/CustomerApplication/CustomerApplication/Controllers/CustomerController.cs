﻿using AutoMapper;
using CustomerApplication.Data;
using CustomerApplication.Models;
using CustomerApplication.UserModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiVersion("1.0", Deprecated = true)]
    public class CustomerController : ControllerBase
    {
        private readonly IDocumentDBRepository<Customer> Respository;
        private readonly string CollectionId;
        private readonly IMapper mapper;
        public CustomerController(IDocumentDBRepository<Customer> Respository,IMapper mapper,IConfiguration configuration)
        {
            this.Respository = Respository;
            CollectionId = configuration.GetValue<string>("Settings:CollectionId");
            this.mapper = mapper;
        }

        [HttpGet]
        public async Task<IEnumerable<CustomerModel>> Get()
        {
            var cust= await Respository.GetItemsAsync(CollectionId);
            List<CustomerModel> results=mapper.Map<List<Customer>,List<CustomerModel>>(cust.ToList());
            return results;
        }

        [HttpGet("{searchTerm}")]
        public async Task<IEnumerable<CustomerModel>> Get(string searchTerm)
        {
            var customers = await Respository.GetItemsAsync(d =>  d.Name == searchTerm || d.id == searchTerm, CollectionId);
            List<CustomerModel> results = mapper.Map<List<Customer>, List<CustomerModel>>(customers.ToList());
            return results;
        }

        [HttpPost]
        public async Task<string> Post([FromBody] CustomerModel customer)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    Customer cust = mapper.Map<CustomerModel,Customer>(customer);
                    bool Custid = await FindById(cust.id);
                    if (Custid)
                    {
                        return "Customer Id Already Exists";
                    }
                    await Respository.CreateItemAsync(cust, CollectionId);
                }
                return "Successfully Created the Customer Record";
            }
            catch
            {
                return "Couldn't create the record.Please check the id and try again";
            }

        }

        [HttpPut]
        public async Task<string> Put([FromBody] CustomerModel customer)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    Customer cust = mapper.Map<CustomerModel, Customer>(customer);
                    bool Custid = await FindById(cust.id);
                    if (!Custid) {
                        return "Customer Id Cannot be Found";
                    }
                    await Respository.UpdateItemAsync(customer.Id, cust, CollectionId);
                }
                return "successfully updated the customer record";
            }
            catch
            {

                return "Oops we couldn't update it.Please check the id and try again later.";
            }
        }

        [HttpDelete("{id}")]
        public async Task<string> Delete(string id)
        {
            try
            {
                bool Custid = await FindById(id);
                if (!Custid)
                {
                    return "Customer Id Cannot be Found";
                }
                await Respository.DeleteItemAsync(id, CollectionId);
                return "Successfully deleted the record";
            }
            catch
            {
                return "Oops cannot delete the record.Try again later";
            }
        }

        public async Task<bool> FindById(string id)
        {
            var customers = await Respository.GetItemsAsync(d => d.id == id, CollectionId);
            if(customers.Count() > 0)
            {
                return true;
            }
            return false;
        }
    }
}

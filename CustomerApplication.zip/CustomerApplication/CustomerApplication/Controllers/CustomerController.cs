﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CustomerApplication.Data;
using CustomerApplication.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CustomerApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly IDocumentDBRepository<Customer> Respository;
        private readonly string CollectionId;
        public CustomerController(IDocumentDBRepository<Customer> Respository)
        {
            this.Respository = Respository;
            CollectionId = "customer-collection";
        }

        [HttpGet]
        public async Task<IEnumerable<Customer>> Get()
        {
            return await Respository.GetItemsAsync(CollectionId);
        }

        [HttpGet("{searchTerm}")]
        public async Task<IEnumerable<Customer>> Get(string searchTerm)
        {
            var customers = await Respository.GetItemsAsync(d =>  d.Name == searchTerm || d.Id == searchTerm, CollectionId);
            Customer customer = new Customer();
            foreach (var cust in customers)
            {
                customer = cust;
                break;
            }
            return customers;
        }

        [HttpPost]
        public async Task<bool> Post([FromBody] Customer customer)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    customer.Id = null;
                    await Respository.CreateItemAsync(customer, CollectionId);
                }
                return true;
            }
            catch
            {
                return false;
            }

        }

        [HttpPut]
        public async Task<bool> Put([FromBody] Customer customer)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    await Respository.UpdateItemAsync(customer.Id, customer, CollectionId);
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        [HttpDelete("{id}/{cityname}")]
        public async Task<bool> Delete(string id, string cityname)
        {
            try
            {
                await Respository.DeleteItemAsync(id, CollectionId, cityname);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}

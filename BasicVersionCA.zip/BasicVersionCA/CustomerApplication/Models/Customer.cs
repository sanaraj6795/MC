﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace CustomerApplication.Models
{
    public class Customer
    {
        public string id { get; set; }

        public string Name { get; set; }

        public Address Address { get; set; }

        public string DateOfBirth { get; set; }
        
        public string PhoneNumber { get; set; }
    }
}

using AutoMapper;
using CustomerApplication.Data;
using CustomerApplication.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiVersion("1.0", Deprecated = true)]
    public class CustomerController : ControllerBase
    {
        private readonly IDocumentDBRepository<Customer> Respository;
        private readonly string CollectionId;
        private readonly IMapper mapper;
        public CustomerController(IDocumentDBRepository<Customer> Respository,IMapper mapper,IConfiguration configuration)
        {
            this.Respository = Respository;
            CollectionId = configuration.GetValue<string>("Settings:CollectionId");
            this.mapper = mapper;
        }

        [HttpGet]
        public async Task<IEnumerable<Customer>> Get()
        {
            return await Respository.GetItemsAsync(CollectionId);
           
        }

        [HttpGet("{searchTerm}")]
        public async Task<IEnumerable<Customer>> Get(string searchTerm)
        {
            return  await Respository.GetItemsAsync(d =>  d.Name == searchTerm || d.id == searchTerm, CollectionId);
        }

        [HttpPost]
        public async Task<string> Post([FromBody] Customer customer)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    await Respository.CreateItemAsync(customer, CollectionId);
                }
                return "Successfully Created the Customer Record";
            }
            catch
            {
                return "Couldn't create the record.Please check the id and try again";
            }

        }

        [HttpPut]
        public async Task<string> Put([FromBody] Customer customer)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    await Respository.UpdateItemAsync(customer.id, customer, CollectionId);
                }
                return "successfully updated the customer record";
            }
            catch
            {

                return "Oops we couldn't update it.Please check the id and try again later.";
            }
        }

        [HttpDelete("{id}")]
        public async Task<string> Delete(string id)
        {
            try
            {
                await Respository.DeleteItemAsync(id, CollectionId);
                return "Successfully deleted the record";
            }
            catch
            {
                return "Oops cannot delete the record.Try again later";
            }
        }
    }
}

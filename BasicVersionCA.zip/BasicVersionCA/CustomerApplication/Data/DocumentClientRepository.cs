﻿using Microsoft.Azure.Documents.Client;
using Microsoft.Extensions.Configuration;
using System;

namespace CustomerApplication.Data
{
    public class DocumentClientRepository: IDocumentClientRepository
    {
        private readonly string Endpoint;
        private readonly string Key;
        public DocumentClientRepository(IConfiguration configuration) 
        {
            Endpoint= configuration.GetValue<string>("Settings:Endpoint");
            Key= configuration.GetValue<string>("Settings:Key");
        }
        public  DocumentClient intialise()
        {
         return new DocumentClient(new Uri(Endpoint), Key);
        }
    }
}

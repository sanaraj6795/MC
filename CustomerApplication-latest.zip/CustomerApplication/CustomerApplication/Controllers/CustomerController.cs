﻿using AutoMapper;
using CustomerApplication.Data;
using CustomerApplication.Models;
using CustomerApplication.UserModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiVersion("1.0", Deprecated = true)]
    public class CustomerController : ControllerBase
    {
        private readonly IDocumentDBRepository<Customer> Respository;
        private readonly string CollectionId;
        private readonly IMapper mapper;
        public CustomerController(IDocumentDBRepository<Customer> Respository,IMapper mapper,IConfiguration configuration)
        {
            this.Respository = Respository;
            CollectionId = configuration.GetValue<string>("Settings:CollectionId");
            this.mapper = mapper;
        }

        [HttpGet]
        public async Task<IEnumerable<CustomerModel>> Get()
        {
            var cust= await Respository.GetItemsAsync(CollectionId);
            List<CustomerModel> results=mapper.Map<List<Customer>,List<CustomerModel>>(cust.ToList());
            return results;
        }

        [HttpGet("{searchTerm}")]
        public async Task<IEnumerable<CustomerModel>> Get(string searchTerm)
        {
            var customers = await Respository.GetItemsAsync(d =>  d.Name == searchTerm || d.id == searchTerm, CollectionId);
            List<CustomerModel> results = mapper.Map<List<Customer>, List<CustomerModel>>(customers.ToList());
            return results;
        }

        [HttpPost]
        public async Task<string> Post([FromBody] CustomerModel customer)
        {
            try
            {
                ResourceResponse<Document> response=new ResourceResponse<Document>();
                if (ModelState.IsValid)
                {
                    Customer cust = mapper.Map<CustomerModel, Customer>(customer);
                    bool Custid = await FindById(cust.id);
                    if (Custid)
                    {
                        return "Customer Id Already Exists";
                    }
                    response = await Respository.CreateItemAsync(cust, CollectionId);
                }
                return "Successfully Created the Customer Record - (StatusCode) : " + response.StatusCode;
            }
            catch(DocumentClientException ex)
            {
                return "Couldn't create the record.Please check the id and try again - (StatusCode) : " + ex.StatusCode;
            }

        }

        [HttpPut]
        public async Task<string> Put([FromBody] CustomerModel customer)
        {
            try
            {
                ResourceResponse<Document> response = new ResourceResponse<Document>();
                if (ModelState.IsValid)
                {
                    Customer cust = mapper.Map<CustomerModel, Customer>(customer);
                    bool Custid = await FindById(cust.id);
                    if (!Custid) {
                        return "Customer Id Cannot be Found";
                    }
                    response =await Respository.UpdateItemAsync(customer.Id, cust, CollectionId);
                }
                return "successfully updated the customer record - (StatusCode) : "+response.StatusCode;
            }
            catch(DocumentClientException ex)
            {

                return "Oops we couldn't update it.Please check the id and try again later - (StatusCode) : "+ ex.StatusCode;
            }
        }

        [HttpDelete("{id}")]
        public async Task<string> Delete(string id)
        {
            try
            {
                bool Custid = await FindById(id);
                if (!Custid)
                {
                    return "Customer Id Cannot be Found";
                }
                ResourceResponse<Document> response=await Respository.DeleteItemAsync(id, CollectionId);
                return "Successfully deleted the record - (StatusCode) : "+response.StatusCode;
            }
            catch(DocumentClientException ex)
            {
                return "Oops cannot delete the record.Try again later - (StatusCode) : " + ex.StatusCode;
            }
        }

        private async Task<bool> FindById(string id)
        {
            var customers = await Respository.GetItemsAsync(d => d.id == id, CollectionId);
            if(customers.Count() > 0)
            {
                return true;
            }
            return false;
        }
    }
}

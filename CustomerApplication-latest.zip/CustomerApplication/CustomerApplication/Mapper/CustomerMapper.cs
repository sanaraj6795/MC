﻿using AutoMapper;
using CustomerApplication.Models;
using CustomerApplication.UserModel;

namespace CustomerApplication.Mapper
{
    public class CustomerMapper : Profile
    {
        public CustomerMapper()
        {
            CreateMap<CustomerModel, Customer>().ReverseMap();
            CreateMap<AddressModel, Address>().ReverseMap();
        }
    }  
    
}

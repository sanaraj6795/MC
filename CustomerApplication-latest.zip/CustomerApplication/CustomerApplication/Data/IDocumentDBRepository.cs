﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CustomerApplication.Data
{
    public interface IDocumentDBRepository<T> where T : class
    {
        Task<ResourceResponse<Document>> CreateItemAsync(T item, string collectionId);
        Task<ResourceResponse<Document>> DeleteItemAsync(string id, string collectionId);
        Task<IEnumerable<T>> GetItemsAsync(Expression<Func<T, bool>> predicate, string collectionId);
        Task<IEnumerable<T>> GetItemsAsync(string collectionId);
        Task<ResourceResponse<Document>> UpdateItemAsync(string id, T item, string collectionId);
    }
}

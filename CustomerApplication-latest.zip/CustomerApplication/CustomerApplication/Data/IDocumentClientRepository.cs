﻿using Microsoft.Azure.Documents.Client;

namespace CustomerApplication.Data
{
    public interface IDocumentClientRepository
    {
        DocumentClient intialise();
    }
}

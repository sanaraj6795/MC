﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace CustomerApplication.UserModel
{
    public class CustomerModel
        {
            [JsonProperty(PropertyName = "id")]
            public string Id { get; set; }

            [JsonProperty(PropertyName = "name")]
            public string Name { get; set; }

            [JsonProperty(PropertyName = "address")]
            public AddressModel Address { get; set; }

            [JsonProperty(PropertyName = "dateOfBirth")]
            public string DateOfBirth { get; set; }

            [JsonProperty(PropertyName = "phoneNumber")]
            public string PhoneNumber { get; set; }
    }

}
